﻿class Atlassian {
    [string]$Auth
    [string]$BaseUrl

    Atlassian([string]$Auth,[string]$BaseUrl) {
            $this.Auth = $Auth
            $this.BaseUrl = $BaseUrl
    }
    [string]getUrl($url){
        return [uri]::EscapeUriString($this.BaseUrl + $url)
    }
    [psobject]get($url){
        $url = $this.getUrl($url)
        $Response = Invoke-WebRequest -URI $url -Headers @{'Content-Type' = 'application/json; charset=utf-8'; 'Authorization' = 'Basic ' + $this.Auth}
        $data = [System.Text.Encoding]::UTF8.GetBytes($Response.Content)
        $data = [System.Text.Encoding]::GetEncoding("UTF-8").GetString($data);
        $data = $data | ConvertFrom-JSON
        return $data
    }
    [Void]put($url, $json){
        $url = $this.getUrl($url)
        $header = @{
        "Authorization"="Basic " + $this.Auth
        "Content-Type"="application/json; charset=utf-8"
        }
    
        Invoke-RestMethod -Uri $url -Method 'Put' -Body $json -Headers $header
    }
    [Void]post($url, $json){
        $url = $this.getUrl($url)
        $header = @{
        "Authorization"="Basic " + $this.Auth
        "Content-Type"="application/json; charset=utf-8"
        }
        Invoke-RestMethod -Uri $url -Method 'Post'-Body $json -Headers $header
    }
    [Void]delete($url){
        $url = $this.getUrl($url)
        $header = @{
        "Authorization"="Basic " + $this.Auth
        "Content-Type"="application/json; charset=utf-8"
        }
        Invoke-RestMethod -Uri $url -Method 'Delete' -Headers $header
    }
}


