﻿## Setup

Bitte eine Datei "constants.ps1" generieren, welche Base64 von username:passwort von JIRA hat:

## Beispiel

base64 of username:password

\$authJIRAIntern = "dXNlcm5hbWU6cGFzc3dvcmQ="
