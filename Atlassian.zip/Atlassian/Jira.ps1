﻿Using module './Atlassian.psm1'
class Jira : Atlassian {
    [string]$Auth
    [string]$BaseUrl
    Jira([string]$Auth,[string]$BaseUrl) : base ([string]$Auth,[string]$BaseUrl){
        
    }
}
