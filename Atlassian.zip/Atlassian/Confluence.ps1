﻿Using module './Atlassian.psm1'
class Confluence : Atlassian {
    [string]$Auth
    [string]$BaseUrl
    Confluence([string]$Auth,[string]$BaseUrl) : base ([string]$Auth,[string]$BaseUrl){       
    }
    
}
